# STL files of all custom miCube components

The id of each component is corresponding to the numbers used in the <a href="https://hohlbeinlab.github.io/miCube/component_table.html">miCube component table</a>.