/*------------------------------------------------
;	File		: SPI.c
;	Part of		: SMILE 328P project
;	Description	: Controls Serial Peripheral Interface
;			initialize SPI hardware function
;           writing unsigned integer to Laser DAC function
;
;	Compiler	: avr-gcc
;	Author		: J.Philippi
;	Copyright	: WUR BioPhysics
;	Version		: 1.0
;
;	Edition history:
;	#   date     comments              by
;	1.0 12-07-19 final		           JPH
;--------------------------------------------------*/

#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>

#define MAXINTENS 0xFFF		// 12bit DAC

 // this routine initializes the PORTB for SPI
 // and PORTC for SPI SYNC.

//	 pin	spi		i/o
//	 PB2 	/ss		nc
//	 PB3	mosi
//	 PB4	miso	nc
//	 PB5	sck

//	 PC0	CS0	
//	 PC1	CS1	
//	 PC2	CS2			
//   PC3	CS3

 void spi_init(void)
 {
	
	 DDRC |= _BV(0)	| _BV(1) | _BV(2) | _BV(3); // Set PC[0..3] to output
	 PORTC |= _BV(0) | _BV(1) | _BV(2) | _BV(3); // Set PC[0..3] to source

	 DDRB |= _BV(2) | _BV(3) | _BV(5); // set /SS, MOSI, SCK to output
	 DDRB &= ~(_BV(4));				   // set MISO to input

	 SPCR = _BV(SPE) | _BV(MSTR) | _BV(CPOL) | _BV(SPR0);  // use clock / 16 = 1 Mhz
 }

void spi_io(uint16_t out, uint8_t LaserNo)
 {
	uint16_t Temp;
									
	if(out <= MAXINTENS) 
		Temp = (out << 2);			// DAC7311 data format
	else
		Temp = (MAXINTENS << 2);	// DAC7311 data max. format

	 PORTC &= ~(_BV(LaserNo-1));	// enable /CS(LaserNo)

	 SPDR = (char)(Temp >> 8);		// send high byte first, 12bit DAC is left aligned 
	 while(!(SPSR & _BV(SPIF)));	// wait until ready
	 SPDR = (char)(Temp & 0x00FF);	// send low byte last
	 while(!(SPSR & _BV(SPIF)));	// wait until ready
	
	PORTC |= _BV(LaserNo-1);		// disable /CS(LaserNo)
 }