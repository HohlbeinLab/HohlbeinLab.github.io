/*------------------------------------------------
;	File		: Timer.c
;	Part of		: SMILE 328P project
;	Description	: Sets Timer0 program,
;			initialize Timer0 hardware function for
;			Interval clock = 16MHz/64 = 250kHz = 4uS * 125 ticks delay = 500us
;
;	Compiler	: avr-gcc
;	Author		: J.Philippi
;	Copyright	: WUR BioPhysics
;	Version		: 1.0
;
;	Edition history:
;	#   date     comments              by
;	1.0 12-07-19 final		           JPH
;--------------------------------------------------*/
// program name: Timer.c
// date: 25-04-2019
// target device: atmega8/atmega328p
// target: 256us interval
// clk= 16MHz/64 = 250kHz = 4uS * 125 ticks delay = 500us tick

 #ifndef F_CPU
 #define F_CPU 16000000UL
 #endif

#include <avr/io.h>
#define Delay 0x83		// FF-7D(=125) <JPH 0x82>

void InitTimer0(void){
	TCCR0A= 0;			// clear Timer Control A
	TCCR0B=_BV(CS01)|_BV(CS00);	//set timer 0 prescaler to clk/64
	TCNT0= Delay;		//set the delay time in Timer Register
	TIMSK0=_BV(TOIE0);	// enable Timer 0 overflow interrupt
}