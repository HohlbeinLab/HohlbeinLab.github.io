/*------------------------------------------------
;	File		: laser.c
;	Part of		: SMILE 328P project
;	Description	: Controls laser & camera IO
;			initialize AT328 portD function
;           Laser On, by laser number, function
;           Laser Off, by laser number, function
;			Laser Toggle, by laser number, function
;			Camera trigger function
;
;	Compiler	: avr-gcc
;	Author		: J.Philippi
;	Copyright	: WUR BioPhysics
;	Version		: 1.0
;
;	Edition history:
;	#   date     comments              by
;	1.0 12-07-19 final		           JPH
;--------------------------------------------------*/

#include <avr/io.h>
#include "Laser.h"

#define DataPort	PORTD	// Using PortD as our Data Port
#define DataIn		PIND
#define DataDDR		DDRD

enum lasercolor {RED = 1, GREEN, BLUE, PURPLE};
enum states {OFF, ON, TOGGLE };

void InitPD(void){
	DataDDR |= 0x7C;	// Configure Data Port PD6..PC2 as output
	DataPort &= 0x83;	// Initialize Data Port PD6..PC2 to 0 (sink)
}

void LaserOn(char c){
	switch (c){
		case RED:
			DataPort |= 0x04;	// set PD2 to high (source)
			break;
		case GREEN:
			DataPort |= 0x08;	// set PD3 to high (source)
			break;
		case BLUE:
			DataPort |= 0x10;	// set PD4 to high (source)
			break;
		case PURPLE:
			DataPort |= 0x20;	// set PD5 to high (source)
			break;
	}
}

void LaserOff(char c){
	switch (c){
		case RED:
			DataPort &= 0xFB;	// set PD2 to low (sink)
			break;
		case GREEN:
			DataPort &= 0xF7;	// set PD3 to low (sink)
			break;
		case BLUE:
			DataPort &= 0xEF;	// set PD4 to low (sink)
			break;
		case PURPLE:
			DataPort &= 0xDF;	// set PD5 to low (sink)
			break;
	}
}

void LaserToggle(char c){
	switch (c){
		case RED:
			DataIn |= 0x04;		// Toggle PD2
			break;
		case GREEN:
			DataIn |= 0x08;		// Toggle PD3
			break;
		case BLUE:
			DataIn |= 0x10;		// Toggle PD4	
			break;
		case PURPLE:
			DataIn |= 0x20;		// Toggle PD5
			break;
	}
}
			
void CameraTriggerPD6(char c){
	switch (c)
	{
		case OFF:
			DataPort &= 0xBF;	// set PD6 to low (sink)
			break;
		case ON:
			DataPort |= 0x40;	// set PD6 to high (source)
			break;
		case TOGGLE:
			DataIn |= 0x40;		// Toggle PD6
			break;
	}
}