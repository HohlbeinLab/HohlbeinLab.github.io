/*
 * main.h
 *
 * Created: 8-6-2017 16:36:03
 *  Author: phili009
 */ 


#ifndef MAIN_H_
#define MAIN_H_

int main(void);

#endif /* MAIN_H_ */