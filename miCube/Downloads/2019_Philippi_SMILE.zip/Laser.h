/*------------------------------------------------
;	File		: laser.h
;	Part of		: SMILE 328P project
;	Description	: Controls laser & camera IO
;			initialize AT328 portD function
;           Laser On, by laser number, function
;           Laser Off, by laser number, function
;			Laser Toggle, by laser number, function
;			Camera trigger function
;
;	Compiler	: avr-gcc
;	Author		: J.Philippi
;	Copyright	: WUR BioPhysics
;	Version		: 1.0
;
;	Edition history:
;	#   date     comments              by
;	1.0 12-07-19 final		           JPH
;--------------------------------------------------*/

#ifndef LASER_H_
#define LASER_H_

void LaserOn(char c);
void LaserOff(char c);
void LaserToggle(char c);
void CameraTriggerPD6(char c);

void InitPD(void);

#endif /* LASER_H */