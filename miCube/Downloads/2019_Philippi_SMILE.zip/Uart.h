/*------------------------------------------------
;	File		: Uart.h
;	Part of		: SMILE 328P project
;	Description	: UART Communication program
;			initialize UART function 
;           writing character function
;           reading character function
;			reading set of characters function
;			test UART buffer empty
;
;	Compiler	: avr-gcc
;	Author		: J.Philippi
;	Copyright	: WUR BioPhysics
;	Version		: 1.0
;
;	Edition history:
;	#   date     comments              by
;	1.0 12-07-19 final		           JPH
;--------------------------------------------------*/

#ifndef UART_H_
#define UART_H_

int uart_putchar(char c, FILE *stream);
int uart_getchar(FILE *stream);
int uart_fgets(char *s, int n, FILE *stream);
int uart_rxc(void);

void uart_init(void);

FILE uart_output = FDEV_SETUP_STREAM(uart_putchar, NULL, _FDEV_SETUP_WRITE);
FILE uart_input = FDEV_SETUP_STREAM(NULL, uart_getchar, _FDEV_SETUP_READ);

#endif /* UART_H_ */