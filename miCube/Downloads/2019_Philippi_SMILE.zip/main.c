/*------------------------------------------------
;	File		: main.c
;	Part of		: SMILE 328P project
;	Description	: Main program 
;			sets laser non interruptible alternation interval
;           decode and assign the telegram from GUI
;           handle the LaserState function    
;			synchronize camera output with lasers
;			synchronize SPI communication for DAC's
;
;	Compiler	: avr-gcc
;	Author		: J.Philippi
;	Copyright	: WUR BioPhysics
;	Version		: 1.0
;
;	Edition history:
;	#   date     comments              by
;	1.0 12-07-19 final		           JPH
;--------------------------------------------------*/

#define F_CPU 16000000UL
 
#include <avr/io.h> 
#include <stdio.h>
#include <stdlib.h>
#include <util/delay.h>
#include <avr/interrupt.h>


#include "main.h"
#include "uart.h"
#include "Laser.h"
#include "Timer.h"
#include "SPI.h"


#define LASERA  0x05		// Laser amount
#define MAXBSZ	0x03		// Telegram size

/// Timer 0 overflow interrupt service routine
enum boolean {FALSE, TRUE};
enum cstatus {MANUAL, RUN};

uint16_t GFrameTime = 0x64;	// default 50msec.
uint8_t GTick = TRUE;
uint8_t GNewFrame = TRUE;
uint8_t GMode = MANUAL;

ISR(TIMER0_OVF_vect){
	#define Delay 0x83				// see Timer.c

	TIMSK0 &= ~_BV(TOIE0);			// disable Timer 0 overflow interrupt

	GTick = TRUE;					// SyncPulse for main()

	TCNT0= Delay;					//set the delay time in Timer Register
	TIMSK0=_BV(TOIE0);				// enable Timer 0 overflow interrupt
}

struct Telegram{
	uint8_t LaserColor :4;	// Laser color
	uint8_t Command :4;		// Manual/Run operation
	uint16_t Data;			// Data Field
};

struct TStorage{
	uint8_t	 ColumnsMask;		//Temporary Frame Sequence Columns Mask
	uint16_t AlterInterval;		//Temporary Alternation Interval
	uint16_t PulseDelay;		//Temporary Pulse Delay
	uint16_t Intensity;			//Temporary laser intensity
	uint16_t FrameNumber;		//Temporary frame number
	uint16_t FrameStep;			//Temporary intensity step size
	uint8_t  FrameTag;			//Temporary new Frame indicator
	uint8_t	 IntensTag;			//Temporary intensity update
	uint8_t	 RunTag;			//Temporary Run condition, to reload settings
};

struct Storage{					
	uint8_t LaserColor :3;	// Laser color
	uint8_t Mode :1;		// Manual/Run operation
	uint8_t LaserStatus :1;	// Laser continues on/off, only in manual mode
	uint8_t FrameSequence;	// reading Frame Sequence, 1 byte
	uint8_t SequenceColumns;// reading Frame Sequence amount of Columns, 1 byte
	uint16_t FrameTime;		// reading Frame Time, 2 bytes
	uint16_t AlterInterval;	// reading Alternation Interval, 2 bytes
	uint16_t PulseDelay;	// reading Pulse Delay, 2 bytes
	uint16_t Intensity;		// reading laser intensity, 2 bytes (DAC 12bit)
	uint16_t FrameStep;		// reading amount of frames per step, 2 bytes (=65535 frames)
	uint16_t FrameNumber;	// reading max.frame number ramping stops, 2 bytes 
	uint16_t StepSize;		// reading intensity step 2 bytes size
	struct TStorage TStore;	// adding volatile data
}*Store;

// This function was build for the following actions:
// 1) decode buffer; determine laser color, command and data word
// 2) assign buffer data to actual laser color structure
// 3) assign buffer data to volatile laser color structure
// 4) assign buffer data to global data needed for ISR

enum commands {MODE = 1, STATUS, SEQUENCE, COLUMNS, ALTER, DELAY, INTENS, FRAMES, STEP, SFRAME, FRAMET, RESET};
enum lasercolor {RED = 1, GREEN, BLUE, PURPLE};
enum cmode {OFF, ON, TOGGLE};
enum defval {EMODE=0, ESTATUS= 0, EALTER=0x64, EDELAY=0, ESEQ=0, ECOL= 0x02, EFSEQ=0, EFNO=0, ESTEP=0, ESFRAM=0, EINTES=0, EFRAM=0x64};

int Decode(char *BufInp, struct Telegram *TelInp , struct Storage *StorInp){
	uint8_t Tag = 0;

	TelInp->LaserColor = BufInp[0] & 0x0F;
	TelInp->Command = (BufInp[0] & 0xF0) >> 4;
	TelInp->Data = (uint16_t)(BufInp[1]<< 8 | BufInp[2]);

	StorInp[TelInp->LaserColor].LaserColor = TelInp->LaserColor;
	switch(TelInp->Command){
		case MODE:
			StorInp[TelInp->LaserColor].Mode = (TelInp->Data != 0) ? RUN : MANUAL;
			GMode = (TelInp->Data != 0) ? RUN : MANUAL;
			StorInp[TelInp->LaserColor].TStore.RunTag = TRUE;
			break;
		case STATUS:
			StorInp[TelInp->LaserColor].LaserStatus = (TelInp->Data != 0) ? ON : OFF;
			break;
		case SEQUENCE:
			StorInp[TelInp->LaserColor].FrameSequence = TelInp->Data;
			break;
		case COLUMNS:
			StorInp[TelInp->LaserColor].SequenceColumns = TelInp->Data;
			StorInp[TelInp->LaserColor].TStore.ColumnsMask = 0;
			break;
		case ALTER:
			StorInp[TelInp->LaserColor].AlterInterval = TelInp->Data;
			StorInp[TelInp->LaserColor].TStore.AlterInterval = TelInp->Data;
			break;
		case DELAY:
			StorInp[TelInp->LaserColor].PulseDelay = TelInp->Data;
			StorInp[TelInp->LaserColor].TStore.PulseDelay = TelInp->Data;
			break;
		case INTENS:
			StorInp[TelInp->LaserColor].Intensity = TelInp->Data;
			StorInp[TelInp->LaserColor].TStore.Intensity = TelInp->Data;
			StorInp[TelInp->LaserColor].TStore.IntensTag = TRUE;
			break;
		case FRAMES:
			StorInp[TelInp->LaserColor].FrameNumber = TelInp->Data;
			StorInp[TelInp->LaserColor].TStore.FrameNumber = TelInp->Data;
			break;
		case STEP:
			StorInp[TelInp->LaserColor].StepSize = TelInp->Data;
			break;
		case SFRAME:
			StorInp[TelInp->LaserColor].FrameStep = TelInp->Data;
			StorInp[TelInp->LaserColor].TStore.FrameStep = TelInp->Data;
			break;
		case FRAMET:
			StorInp[TelInp->LaserColor].FrameTime = TelInp->Data;
			GFrameTime = TelInp->Data;
			break;
		case RESET:
			StorInp[TelInp->LaserColor].Mode = EMODE;
			StorInp[TelInp->LaserColor].TStore.RunTag = FALSE;
			StorInp[TelInp->LaserColor].LaserStatus = ESTATUS;
			StorInp[TelInp->LaserColor].FrameSequence = ESEQ;
			StorInp[TelInp->LaserColor].SequenceColumns = ECOL;
			StorInp[TelInp->LaserColor].TStore.ColumnsMask = 0;
			StorInp[TelInp->LaserColor].AlterInterval = EALTER;
			StorInp[TelInp->LaserColor].TStore.AlterInterval = EALTER;
			StorInp[TelInp->LaserColor].PulseDelay = EDELAY;
			StorInp[TelInp->LaserColor].TStore.PulseDelay = EDELAY;
			StorInp[TelInp->LaserColor].Intensity = EINTES;
			StorInp[TelInp->LaserColor].TStore.Intensity = EINTES;
			StorInp[TelInp->LaserColor].FrameNumber = EFNO;
			StorInp[TelInp->LaserColor].TStore.FrameNumber = EFNO;
			StorInp[TelInp->LaserColor].StepSize = ESTEP;
			StorInp[TelInp->LaserColor].FrameStep = ESFRAM;
			StorInp[TelInp->LaserColor].TStore.FrameStep = ESFRAM;
			StorInp[TelInp->LaserColor].TStore.IntensTag = TRUE;
			StorInp[TelInp->LaserColor].FrameTime = EFRAM;
			GFrameTime = EFRAM;
			break;
		default:
			Tag = 1;
			break;
	}
	return(Tag);
}


// This function reload all the process variables in case:
// controller power loss
// terminate the GUI

int Reload(struct Storage *StorInp){

	StorInp->Mode = EMODE;
	StorInp->LaserStatus = ESTATUS;
	StorInp->FrameSequence = EFSEQ;
	StorInp->SequenceColumns = ECOL;
	StorInp->TStore.ColumnsMask = 0;
	StorInp->AlterInterval = EALTER;
	StorInp->TStore.AlterInterval = EALTER;
	StorInp->PulseDelay = EDELAY;
	StorInp->TStore.PulseDelay = EDELAY;
	StorInp->Intensity = EINTES;
	StorInp->TStore.Intensity = EINTES;
	StorInp->TStore.IntensTag = TRUE;
	StorInp->FrameNumber = EFNO;
	StorInp->TStore.FrameNumber = EFNO;
	StorInp->StepSize = ESTEP;
	StorInp->FrameStep = ESFRAM;
	StorInp->TStore.FrameStep = ESFRAM;
	StorInp->FrameTime = EFRAM;
	GFrameTime = EFRAM;

	return(0);
}


//THis function controls the lasers for the different modes of the program
//It handles: the manual/run mode and its status
//It handles: the pre and post delay as well the alternation interval
//On top of that it needs to stay in sync with the camera timing..



void LaserState (struct Storage *StorInp){
	if(GMode){															// running mode
		if(GNewFrame){
			StorInp->TStore.FrameTag = TRUE;							// new frame detection
			if((StorInp->FrameSequence & _BV(StorInp->TStore.ColumnsMask))){
				if(!(StorInp->TStore.PulseDelay--)){
					StorInp->TStore.PulseDelay = 0;						// undo the subtraction
					if(StorInp->TStore.AlterInterval--)LaserOn(StorInp->LaserColor);
					else{ 
						LaserOff(StorInp->LaserColor);					// off by post delay
						StorInp->TStore.AlterInterval = 0;				// undo the subtraction
					}
				}
				else LaserOff(StorInp->LaserColor);						// off by pre delay
			}	
			else LaserOff(StorInp->LaserColor);							// off by frame sequence
		}
		else{					
			if(StorInp->TStore.FrameTag){								// odd frame 
				StorInp->TStore.FrameTag = FALSE;						// initialization for new frame done
				LaserOff(StorInp->LaserColor);							// off by odd frame
				if((StorInp->SequenceColumns-1) == StorInp->TStore.ColumnsMask )
					StorInp->TStore.ColumnsMask = 0;					//reset mask
				else
					StorInp->TStore.ColumnsMask++;						//next mask position
				StorInp->TStore.AlterInterval = StorInp->AlterInterval; // reload Alternation interval in odd frame
				StorInp->TStore.PulseDelay = StorInp->PulseDelay;		// reload Alternation delay in odd frame
																		// intensity linear ramping section
				if(StorInp->StepSize){									// if StepSize == 0, there nothing to do
					if(StorInp->TStore.RunTag){
						StorInp->TStore.Intensity = StorInp->Intensity;	// reload Intensity
						StorInp->TStore.FrameNumber = StorInp ->FrameNumber; // reload FrameNumber
						StorInp->TStore.FrameStep = StorInp->FrameStep;	// reload FrameStep
						StorInp->TStore.IntensTag = TRUE;				// update Intensity
						StorInp->TStore.RunTag = FALSE;					// run only once
					}
					if((!StorInp->TStore.FrameStep) && (StorInp->TStore.FrameNumber)){
						StorInp->TStore.Intensity += StorInp->StepSize;	// increase intensity by StepSize
						StorInp->TStore.FrameStep = StorInp->FrameStep;	// next FrameStep
						StorInp->TStore.IntensTag = TRUE;				// update Intensity
					}
				}
				if(StorInp->TStore.IntensTag){
					spi_io(StorInp->TStore.Intensity,StorInp->LaserColor);// set Intensity
					StorInp->TStore.IntensTag = FALSE;					// update Intensity only once
				}														// decrease FrameNumber & FrameStep
				if(StorInp->TStore.FrameNumber) StorInp->TStore.FrameNumber--;
				if(StorInp->TStore.FrameStep) StorInp->TStore.FrameStep--;
			}
		}
	}
	else{
		(StorInp->LaserStatus) ? LaserOn(StorInp->LaserColor) : LaserOff(StorInp->LaserColor);	// Manual mode
		if(StorInp->TStore.IntensTag){
			 spi_io(StorInp->Intensity,StorInp->LaserColor);			// set Intensity
			 StorInp->TStore.IntensTag = FALSE;							// update Intensity only once
		}						
	}
}


int main(void) {
	cli();
	uart_init();
	InitPD();
	InitTimer0();
	spi_init();
	sei();

	stdout = &uart_output;
	stdin  = &uart_input;

	struct Storage Lasers[LASERA] = {{0}};
	struct Telegram RxData ={0};

	char buffer[sizeof(RxData)];
	uint16_t Teller = GFrameTime;
	
	Reload(&Lasers[RED]);									//initialize Red laser settings
	Reload(&Lasers[GREEN]);									//initialize Green laser settings
	Reload(&Lasers[BLUE]);									//initialize Blue laser settings
	Reload(&Lasers[PURPLE]);								//initialize Purple laser settings

	while(TRUE){
		if(GTick){
			if(!(--Teller)){
				GNewFrame = (GNewFrame) ? FALSE : TRUE;		// Toggle Sync Pulse for a new Frame
					Teller = (GMode) ? GFrameTime : 1;		// Only Reload Frame Time in RUN mode
			}
			(GNewFrame && GMode) ? CameraTriggerPD6(ON) : CameraTriggerPD6(OFF); // operate camera
			LaserState(&Lasers[RED]);						// operate RED Laser in sync
			LaserState(&Lasers[GREEN]);						// operate GREEN Laser in sync
			LaserState(&Lasers[BLUE]);						// operate BLUE Laser in sync
			LaserState(&Lasers[PURPLE]);					// operate PURPLE Laser in sync
			GTick = FALSE;									// seen 500us Timer tick
		}
		if(uart_rxc()){
			uart_fgets(buffer,MAXBSZ,stdin);				//read Telegram
			fflush(stdin);									//flush stdin
			Decode(buffer, &RxData, Lasers);				// start Decode received buffer data
		}
	}
	return 0;
}