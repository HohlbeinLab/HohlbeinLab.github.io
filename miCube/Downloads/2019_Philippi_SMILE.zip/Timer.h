/*------------------------------------------------
;	File		: Timer.h
;	Part of		: SMILE 328P project
;	Description	: Sets Timer0 program,
;			initialize Timer0 hardware function for
;			Interval clock = 16MHz/64 = 250kHz = 4uS * 125 ticks delay = 500us
;
;	Compiler	: avr-gcc
;	Author		: J.Philippi
;	Copyright	: WUR BioPhysics
;	Version		: 1.0
;
;	Edition history:
;	#   date     comments              by
;	1.0 12-07-19 final		           JPH
;--------------------------------------------------*/

#ifndef TIMER_H_
#define TIMER_H_

void InitTimer0(void);

#endif /* TIMER_H */